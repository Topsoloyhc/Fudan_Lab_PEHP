# coding = utf-8

import numpy as np
import cv2
from PIL import Image

import Cropper_testCode

class Validator(object):

    def __init__(self, config):
        self.__config = config

    def validate(self):
        for i in range(1, 101):
            img, imgHid, resultImg, resultHid, resultBbox, originalBbox = self.createInfo(i)
            mask = (imgHid == i)
            newBbox, oldBbox, canvas, imgHid = Cropper_testCode.Cropper(self.__config).cropInstance(mask, img, imgHid)
            conditions = [('resultImg.shape != canvas.shape', '图像' + str(i) + '切割后的图像shape不一样'),
                          ('not (resultImg == canvas).all()', '图像' + str(i) + '切割后的图像跟预计的不一样'),
                          ('imgHid.shape != resultHid.shape', '图像' + str(i) + '切割后的imgHid的shape不一样'),
                          ('not (imgHid == resultHid).all()', '图像' + str(i) + '切割后的imgHid跟预计的不一样'),
                          ('originalBbox != oldBbox', '图像' + str(i) + '初始获取的包围盒的部分不正确'),
                          ('resultBbox != newBbox', '图像' + str(i) + '计算新的包围盒的函数不正确')]

            for expr, msg in conditions:
                if eval(expr):
                    print(msg)
                    break
            else:
                print('图像' + str(i) + '所有部分均正确')

    def createInfo(self, index): #index是左上角的图标，每个图像包含一个实例（2*2的矩形实例）
        img = np.zeros((102, 102, 3)) #101保证有100个case
        img[index][index] = [index , 255, 255] # 左上角背景
        img[index + 1][index], img[index][index + 1], img[index + 1][index + 1] = [[index, 0 , 0]] * 3 # 其余三个像素为实例部分
        imgHid = np.zeros((102, 102))
        imgHid[index + 1][index], imgHid[index][index + 1], imgHid[index + 1][index + 1] = [index] * 3
        resultImg = np.zeros((2, 2, 3))
        resultImg[0][0] = [0, 255, 0]
        resultImg[0][1], resultImg[1][0], resultImg[1][1] = [[index, 0 , 0]] * 3
        resultHid = np.zeros((2, 2))
        resultHid[0][1], resultHid[1][0], resultHid[1][1] = [index] * 3
        originalBbox = [index, index, 2, 2]
        resultBbox = [index - 1, index - 1, 2, 2]
        return img, imgHid, resultImg, resultHid, resultBbox, originalBbox


if __name__ == "__main__":
    config = {
        'path': 'slice/',
        'rootpath': 'slice/',
        'writepath': 'slice/crop/',
        'imagepath': 'slice/Images/',
        'instancepath': 'slice/Instances/',
        'ratio': 0.15,
        'is_reCrop':True,
    }
    Validator(config).validate()
    # a = np.zeros((1,1))
    # b = np.zeros((1,1,2))
    # print((a == b).all())