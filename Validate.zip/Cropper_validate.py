# coding = utf-8

import numpy as np
import cv2
from PIL import Image

import Cropper_testCode

class Validator(object):

    def __init__(self, config):
        self.__config = config

    def validate(self):
        # img, imgHid, resultImg, resultHid, resultBbox, originalBbox = self.createInfo()
        # mask = (imgHid == 1)
        # newBbox, oldBbox, canvas, imgHid = Cropper_testCode.Cropper(self.__config).cropInstance(mask, img, imgHid)
        # instanceNum = len(np.unique(imgHid))
        # for instance_index in range(1, instanceNum):

        img1, imgHid1, resultImg1, resultHid1, resultBbox1, originalBbox1, resultImg2, resultHid2, resultBbox2, originalBbox2 = self.createInfo2()
        img2, imgHid2, resultImg1, resultHid1, resultBbox1, originalBbox1, resultImg2, resultHid2, resultBbox2, originalBbox2 = self.createInfo2()
        cropper = Cropper_testCode.Cropper(self.__config)
        mask1 = (imgHid1 == 1)
        newBbox1, oldBbox1, canvas1, imgHid1 = cropper.cropInstance(mask1, img1, imgHid1)
        mask2 = (imgHid2 == 2)
        newBbox2, oldBbox2, canvas2, imgHid2 = cropper.cropInstance(mask2, img2, imgHid2)
        img, imgHid, resultImg, resultHid, resultBbox, originalBbox = self.createInfo1()
        mask = (imgHid == 1)
        newBbox, oldBbox, canvas, imgHid = cropper.cropInstance(mask, img, imgHid)


        conditions = [('resultImg.shape != canvas.shape', '图像一切割后的图像shape不一样'),
                      ('not (resultImg == canvas).all()', '图像一切割后的图像跟预计的不一样'),
                      ('imgHid.shape != resultHid.shape', '图像一切割后的imgHid的shape不一样'),
                      ('not (imgHid == resultHid).all()', '图像一切割后的imgHid跟预计的不一样'),
                      ('originalBbox != oldBbox', '图像一初始获取的包围盒的部分不正确'),
                      ('resultBbox != newBbox', '图像一计算新的包围盒的函数不正确')]

        for expr, msg in conditions:
            if eval(expr):
                print(msg)
                break
        else:
            print('图像一所有部分均正确')

        conditions = [('resultImg1.shape != canvas1.shape', '图像二实例1切割后的图像shape不一样'),
                      ('not (resultImg1 == canvas1).all()', '图像二实例1切割后的图像跟预计的不一样'),
                      ('imgHid1.shape != resultHid1.shape', '图像二实例1切割后的imgHid的shape不一样'),
                      ('not (imgHid1 == resultHid1).all()', '图像二实例1切割后的imgHid跟预计的不一样'),
                      ('originalBbox1 != oldBbox1', '图像二实例1初始获取的包围盒的部分不正确'),
                      ('resultBbox1 != newBbox1', '图像二实例1计算新的包围盒的函数不正确'),

                      ('resultImg2.shape != canvas2.shape', '图像二实例2切割后的图像shape不一样'),
                      ('not (resultImg2 == canvas2).all()', '图像二实例2切割后的图像跟预计的不一样'),
                      ('imgHid2.shape != resultHid2.shape', '图像二实例2切割后的imgHid的shape不一样'),
                      ('not (imgHid2 == resultHid2).all()', '图像二实例2切割后的imgHid跟预计的不一样'),
                      ('originalBbox2 != oldBbox2', '图像二实例2初始获取的包围盒的部分不正确'),
                      ('resultBbox2 != newBbox2', '图像二实例2计算新的包围盒的函数不正确')]

        for expr, msg in conditions:
            if eval(expr):
                print(msg)
                break
        else:
            print('图像二所有部分均正确')

        # Cropper_testCode.Cropper(self.__config).cropOneImg(1)
        # name = '0000001_01'
        # image = self.__config['writepath'] + 'Images/' + name + '.jpg'
        # imageHid = self.__config['writepath'] + 'Human_ids/' + name + '.png'
        # canvas = cv2.imread(image)
        # imgHid = np.array(Image.open(np.str(imageHid)))


    def createInfo1(self):
        #要切割的图像
        img = np.zeros((10, 10, 3))
        img[4][5], img[5][4], img[5][5] = [255, 0, 0], [255, 0, 0], [255, 0, 0]
        # 结果图像
        resultImg = np.zeros((2, 2, 3))
        resultImg[0][0], resultImg[0][1], resultImg[1][0], resultImg[1][1] = [0, 255, 0], [255, 0, 0], [255, 0, 0], [255, 0, 0]
        # cv2.imwrite(self.__config['path'] + 'Images/0000001.jpg', img)
        #imgHid的数据
        imgHid = np.zeros((10, 10))
        imgHid[4][5], imgHid[5][4], imgHid[5][5] = [1] * 3
        # cv2.imwrite(self.__config['path'] + 'Human_ids/0000001.png', imgHid)
        #结果Hid
        resultHid = np.zeros((2, 2))
        resultHid[0][1], resultHid[1][0], resultHid[1][1] = [1] * 3
        resultBbox = [3, 3, 2, 2]
        originalBbox = [4, 4, 2, 2]
        return img, imgHid, resultImg, resultHid, resultBbox, originalBbox

    def createInfo2(self):
        # 要切割的图像，设置两个实例，每个实例由两个2*2的矩形所表示，保证两个实例的Bbox扩大后有重叠部分
        img = np.zeros((100, 100, 3))
        #实例一,左上角，右下角2*2矩形，oldBbox = [2, 2, 21, 21], newBbox = [0, 0, 25, 25]
        img[2][2], img[2][3], img[3][2], img[3][3] = [[255, 0, 0]] * 4
        img[21][21], img[22][21], img[21][22], img[22][22] = [[255, 0, 0]] * 4
        # 实例二,左上角，右下角2*2矩形, oldBbox = [23, 23, 21, 21], newBbox = [19, 19, 27, 27]
        img[23][23], img[23][24], img[24][23], img[24][24] = [[255, 255, 0]] * 4
        img[42][42], img[42][43], img[43][42], img[43][43] = [[255, 255, 0]] * 4
        # imgHid的数据
        imgHid = np.zeros((100, 100))
        imgHid[2][2], imgHid[2][3], imgHid[3][2], imgHid[3][3], imgHid[21][21], imgHid[22][21], imgHid[21][22], imgHid[22][22] = [1] * 8
        imgHid[23][23], imgHid[23][24], imgHid[24][23], imgHid[24][24], imgHid[42][42], imgHid[42][43], imgHid[43][42], imgHid[43][43] = [2] * 8
        # cv2.imwrite(self.__config['path'] + 'Images/0000002.jpg', img)
        # 结果图像
        resultImg1 = np.zeros((25, 25, 3))
        for i in range(25):
            resultImg1[i] = [[0,255,0]] * 25
        resultImg1[2][2], resultImg1[2][1], resultImg1[1][2], resultImg1[1][1], resultImg1[21][21], resultImg1[20][21], resultImg1[21][20], resultImg1[20][20] = [[255, 0, 0]] * 8
        resultImg2 = np.zeros((27, 27, 3))
        for i in range(27):
            resultImg2[i] = [[0,255,0]] * 27
        resultImg2[3][3], resultImg2[3][4], resultImg2[4][3], resultImg2[4][4], resultImg2[22][22], resultImg2[22][23], resultImg2[23][22], resultImg2[23][23] = [[255, 255, 0]] * 8
        # 结果Hid
        resultHid1 = np.zeros((25, 25))
        resultHid1[2][2], resultHid1[2][1], resultHid1[1][2], resultHid1[1][1], resultHid1[21][21], resultHid1[20][21], resultHid1[21][20], resultHid1[20][20] = [1] * 8
        resultHid1[22][22], resultHid1[22][23], resultHid1[23][22], resultHid1[23][23] = [2] * 4 # 包围盒扩大后将实例二的部分包括进来了
        resultHid2 = np.zeros((27, 27))
        resultHid2[3][3], resultHid2[3][4], resultHid2[4][3], resultHid2[4][4], resultHid2[22][22], resultHid2[22][23], resultHid2[23][22], resultHid2[23][23] = [2] * 8
        resultHid2[2][2], resultHid2[2][1], resultHid2[1][2], resultHid2[1][1] = [1] * 4  # 包围盒扩大后将实例一的部分包括进来了

        originalBbox1, resultBbox1 = [2, 2, 21, 21], [0, 0, 25, 25]
        originalBbox2, resultBbox2 = [23, 23, 21, 21], [19, 19, 27, 27]

        return img, imgHid, resultImg1, resultHid1, resultBbox1, originalBbox1, resultImg2, resultHid2, resultBbox2, originalBbox2



if __name__ == "__main__":
    config = {
        'path': 'slice/',
        'rootpath': 'slice/',
        'writepath': 'slice/crop/',
        'imagepath': 'slice/Images/',
        'instancepath': 'slice/Instances/',
        'ratio': 0.15,
        'is_reCrop':True,
    }
    Validator(config).validate()
    # a = np.zeros((1,1))
    # b = np.zeros((1,1,2))
    # print((a == b).all())